import { Sun, Moon, Fish, Clock, TrendingUp } from 'lucide-react';

export default function FishActivity() {
  // Mock solunar data - in production this would come from Nautide Pro API
  const today = new Date();
  const currentHour = today.getHours();
  const currentMinute = today.getMinutes();
  const currentTime = currentHour * 60 + currentMinute;

  const solunarData = {
    date: today.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' }),
    moonPhase: 'Waxing Gibbous',
    moonIllumination: 78,
    sunrise: '06:32',
    sunset: '19:48',
    moonrise: '15:24',
    moonset: '03:12',
    rating: 4, // 1-5 scale
    majorPeriods: [
      { start: '05:45', end: '07:45', peak: '06:45', type: 'major' },
      { start: '18:15', end: '20:15', peak: '19:15', type: 'major' },
    ],
    minorPeriods: [
      { start: '00:00', end: '01:00', peak: '00:30', type: 'minor' },
      { start: '12:30', end: '13:30', peak: '13:00', type: 'minor' },
    ],
  };

  const allPeriods = [...solunarData.majorPeriods, ...solunarData.minorPeriods].sort((a, b) => {
    const aTime = parseInt(a.start.split(':')[0]) * 60 + parseInt(a.start.split(':')[1]);
    const bTime = parseInt(b.start.split(':')[0]) * 60 + parseInt(b.start.split(':')[1]);
    return aTime - bTime;
  });

  const timeToMinutes = (time: string) => {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  };

  const isActive = (start: string, end: string) => {
    const startMin = timeToMinutes(start);
    const endMin = timeToMinutes(end);
    return currentTime >= startMin && currentTime <= endMin;
  };

  const getNextPeriod = () => {
    for (const period of allPeriods) {
      const startMin = timeToMinutes(period.start);
      if (currentTime < startMin) {
        return period;
      }
    }
    return allPeriods[0]; // Next day's first period
  };

  const activePeriod = allPeriods.find((p) => isActive(p.start, p.end));
  const nextPeriod = activePeriod ? null : getNextPeriod();

  const getRatingColor = (rating: number) => {
    if (rating >= 4) return 'text-green-400';
    if (rating >= 3) return 'text-yellow-400';
    return 'text-orange-400';
  };

  const getRatingLabel = (rating: number) => {
    if (rating >= 4) return 'Excellent';
    if (rating >= 3) return 'Good';
    if (rating >= 2) return 'Fair';
    return 'Poor';
  };

  return (
    <div className="bg-slate-800 rounded-xl p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Fish className="text-blue-400" size={24} />
            <h2 className="font-semibold text-lg">Fish Activity Forecast</h2>
          </div>
          <p className="text-xs text-slate-400">{solunarData.date}</p>
        </div>
        <div className="text-right">
          <p className={`text-2xl font-bold ${getRatingColor(solunarData.rating)}`}>
            {solunarData.rating}/5
          </p>
          <p className="text-xs text-slate-400">{getRatingLabel(solunarData.rating)}</p>
        </div>
      </div>

      {/* Current/Next Period */}
      {activePeriod ? (
        <div className="bg-green-600 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-3 h-3 bg-white rounded-full animate-pulse"></div>
            <h3 className="font-semibold">ACTIVE NOW - {activePeriod.type.toUpperCase()} PERIOD</h3>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm opacity-90">Peak: {activePeriod.peak}</p>
              <p className="text-xs opacity-75">Ends: {activePeriod.end}</p>
            </div>
            <div className="text-right">
              <p className="text-xs opacity-75">Window Duration</p>
              <p className="font-bold text-lg">2 hours</p>
            </div>
          </div>
        </div>
      ) : nextPeriod ? (
        <div className="bg-blue-900/50 border border-blue-600 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Clock size={16} className="text-blue-400" />
            <h3 className="font-semibold">NEXT {nextPeriod.type.toUpperCase()} PERIOD</h3>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm">Starts: {nextPeriod.start}</p>
              <p className="text-xs text-slate-400">Peak: {nextPeriod.peak}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-400">Duration</p>
              <p className="font-bold">
                {nextPeriod.type === 'major' ? '2 hrs' : '1 hr'}
              </p>
            </div>
          </div>
        </div>
      ) : null}

      {/* Moon Phase */}
      <div className="bg-slate-900 rounded-lg p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Moon size={18} className="text-slate-400" />
            <span className="text-sm font-semibold">Moon Phase</span>
          </div>
          <span className="text-sm">{solunarData.moonPhase}</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-400 rounded-full"
              style={{ width: `${solunarData.moonIllumination}%` }}
            ></div>
          </div>
          <span className="text-xs text-slate-400">{solunarData.moonIllumination}%</span>
        </div>
      </div>

      {/* Timeline View */}
      <div>
        <h3 className="text-sm font-semibold mb-3">Today's Activity Windows</h3>
        <div className="space-y-2">
          {allPeriods.map((period, index) => {
            const isPast = timeToMinutes(period.end) < currentTime;
            const isCurrentlyActive = isActive(period.start, period.end);

            return (
              <div
                key={index}
                className={`flex items-center gap-3 p-3 rounded-lg ${
                  isCurrentlyActive
                    ? 'bg-green-600'
                    : period.type === 'major'
                    ? 'bg-slate-700'
                    : 'bg-slate-700/50'
                } ${isPast ? 'opacity-40' : ''}`}
              >
                <div
                  className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    period.type === 'major' ? 'bg-orange-500' : 'bg-blue-500'
                  }`}
                >
                  {period.type === 'major' ? (
                    <TrendingUp size={20} />
                  ) : (
                    <Fish size={20} />
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-sm capitalize">{period.type} Period</p>
                    {isCurrentlyActive && (
                      <span className="text-xs bg-white text-green-600 px-2 py-0.5 rounded-full font-bold">
                        ACTIVE
                      </span>
                    )}
                    {isPast && (
                      <span className="text-xs text-slate-500">Past</span>
                    )}
                  </div>
                  <p className="text-xs text-slate-300">
                    {period.start} - {period.end} (Peak: {period.peak})
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sun & Moon Times */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-slate-900 rounded-lg p-3">
          <div className="flex items-center gap-2 mb-2">
            <Sun size={16} className="text-yellow-400" />
            <span className="text-xs text-slate-400">Sun</span>
          </div>
          <div className="text-sm space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-400">Rise:</span>
              <span className="font-semibold">{solunarData.sunrise}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Set:</span>
              <span className="font-semibold">{solunarData.sunset}</span>
            </div>
          </div>
        </div>
        <div className="bg-slate-900 rounded-lg p-3">
          <div className="flex items-center gap-2 mb-2">
            <Moon size={16} className="text-blue-400" />
            <span className="text-xs text-slate-400">Moon</span>
          </div>
          <div className="text-sm space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-400">Rise:</span>
              <span className="font-semibold">{solunarData.moonrise}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Set:</span>
              <span className="font-semibold">{solunarData.moonset}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Info Box */}
      <div className="bg-blue-900/30 border border-blue-600 rounded-lg p-3">
        <p className="text-xs text-blue-200">
          <strong>Solunar Theory:</strong> Fish are most active during major periods (moon overhead/underfoot)
          and minor periods (moonrise/moonset). Plan your trip around these windows for best results.
        </p>
      </div>
    </div>
  );
}
