import { useState, useEffect } from 'react';
import { AlertCircle, CheckCircle, XCircle, Info } from 'lucide-react';

export default function PWADebugger() {
  const [checks, setChecks] = useState({
    https: false,
    serviceWorker: false,
    manifest: false,
    icons: false,
    standalone: false,
  });
  const [swStatus, setSwStatus] = useState('checking...');
  const [manifestData, setManifestData] = useState<any>(null);
  const [installPromptAvailable, setInstallPromptAvailable] = useState(false);
  const [showDebug, setShowDebug] = useState(false);

  useEffect(() => {
    runChecks();

    // Listen for install prompt
    const handleBeforeInstallPrompt = () => {
      setInstallPromptAvailable(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const runChecks = async () => {
    // Check HTTPS
    const isHttps = window.location.protocol === 'https:' || window.location.hostname === 'localhost';

    // Check if already in standalone mode
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches;

    // Check Service Worker
    let swRegistered = false;
    let swActive = false;
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.getRegistration();
        swRegistered = !!registration;
        swActive = registration?.active?.state === 'activated';

        if (swActive) {
          setSwStatus('✅ Active and running');
        } else if (swRegistered) {
          setSwStatus('⏳ Registered, activating...');
        } else {
          setSwStatus('❌ Not registered');
        }
      } catch (error) {
        setSwStatus('❌ Error: ' + error);
      }
    } else {
      setSwStatus('❌ Not supported');
    }

    // Check Manifest (try both .webmanifest and .json)
    let manifestOk = false;
    try {
      // VitePWA generates .webmanifest file
      let response = await fetch('/manifest.webmanifest');
      if (!response.ok) {
        // Fallback to .json
        response = await fetch('/manifest.json');
      }

      if (response.ok) {
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
          const data = await response.json();
          setManifestData(data);
          manifestOk = true;
        }
      }
    } catch (error) {
      console.error('Manifest check failed:', error);
    }

    // Check Icons
    let iconsOk = false;
    try {
      const icon192 = await fetch('/pwa-192x192.png');
      const icon512 = await fetch('/pwa-512x512.png');
      iconsOk = icon192.ok && icon512.ok;
    } catch (error) {
      console.error('Icon check failed:', error);
    }

    setChecks({
      https: isHttps,
      serviceWorker: swActive,
      manifest: manifestOk,
      icons: iconsOk,
      standalone: isStandalone,
    });
  };

  const StatusIcon = ({ status }: { status: boolean }) => {
    return status ? (
      <CheckCircle className="text-green-400" size={20} />
    ) : (
      <XCircle className="text-red-400" size={20} />
    );
  };

  const allChecksPass = checks.https && checks.serviceWorker && checks.manifest && checks.icons;

  return (
    <div className="bg-slate-800 rounded-xl p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Info className="text-blue-400" size={20} />
          <h3 className="font-semibold">PWA Status</h3>
        </div>
        <button
          onClick={() => setShowDebug(!showDebug)}
          className="text-sm text-blue-400 hover:text-blue-300"
        >
          {showDebug ? 'Hide Details' : 'Show Details'}
        </button>
      </div>

      {/* Quick Status */}
      {!showDebug && (
        <div className={`rounded-lg p-3 ${allChecksPass ? 'bg-green-900/30 border border-green-600' : 'bg-yellow-900/30 border border-yellow-600'}`}>
          {allChecksPass ? (
            <p className="text-green-400 font-semibold">✅ PWA Ready to Install!</p>
          ) : (
            <p className="text-yellow-400 font-semibold">⚠️ PWA Setup Issues Detected</p>
          )}
          <p className="text-sm text-slate-300 mt-1">
            {installPromptAvailable ? 'Install prompt available' : 'Waiting for install prompt...'}
          </p>
        </div>
      )}

      {/* Detailed Debug */}
      {showDebug && (
        <div className="space-y-2 text-sm">
          <div className="bg-slate-900 rounded-lg p-3 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">HTTPS / Secure Context</span>
              <StatusIcon status={checks.https} />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Service Worker</span>
              <StatusIcon status={checks.serviceWorker} />
            </div>
            <div className="text-xs text-slate-500 ml-4">{swStatus}</div>

            <div className="flex items-center justify-between">
              <span className="text-slate-400">Manifest File</span>
              <StatusIcon status={checks.manifest} />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-400">Icon Files</span>
              <StatusIcon status={checks.icons} />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-400">Install Prompt</span>
              <StatusIcon status={installPromptAvailable} />
            </div>

            {checks.standalone && (
              <div className="mt-2 p-2 bg-green-900/30 rounded">
                <p className="text-green-400 text-xs font-semibold">
                  ✅ Already installed! Running in standalone mode.
                </p>
              </div>
            )}
          </div>

          {/* Manifest Info */}
          {manifestData && (
            <div className="bg-slate-900 rounded-lg p-3">
              <p className="font-semibold mb-2 text-xs">Manifest Details:</p>
              <div className="text-xs text-slate-400 space-y-1">
                <div>Name: {manifestData.name}</div>
                <div>Display: {manifestData.display}</div>
                <div>Icons: {manifestData.icons?.length || 0} defined</div>
              </div>
            </div>
          )}

          {/* Platform Info */}
          <div className="bg-slate-900 rounded-lg p-3">
            <p className="font-semibold mb-2 text-xs">Platform Info:</p>
            <div className="text-xs text-slate-400 space-y-1">
              <div>User Agent: {navigator.userAgent.substring(0, 60)}...</div>
              <div>Protocol: {window.location.protocol}</div>
              <div>Display Mode: {window.matchMedia('(display-mode: standalone)').matches ? 'standalone' : 'browser'}</div>
            </div>
          </div>

          {/* Troubleshooting */}
          {!allChecksPass && (
            <div className="bg-yellow-900/30 border border-yellow-600 rounded-lg p-3">
              <p className="text-yellow-400 font-semibold text-xs mb-2">Troubleshooting Steps:</p>
              <ul className="text-xs text-yellow-200 space-y-1 list-disc list-inside">
                {!checks.https && <li>Must be HTTPS or localhost</li>}
                {!checks.serviceWorker && <li>Hard refresh: Ctrl+Shift+R</li>}
                {!checks.manifest && <li>Check manifest.json exists</li>}
                {!checks.icons && <li>Check icon files in /public</li>}
                {!installPromptAvailable && (
                  <>
                    <li>Visit site 2+ times with 5 min gap</li>
                    <li>Engage with site (scroll, click)</li>
                    <li>Close all tabs and reopen</li>
                  </>
                )}
              </ul>
            </div>
          )}

          <button
            onClick={runChecks}
            className="w-full bg-blue-600 hover:bg-blue-700 py-2 rounded-lg text-sm font-semibold"
          >
            Re-check Status
          </button>
        </div>
      )}
    </div>
  );
}
