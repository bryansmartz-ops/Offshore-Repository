import { useState } from 'react';
import { TrendingUp, MapPin, Fish, Zap, Clock, Navigation2, AlertTriangle } from 'lucide-react';
import DataSourceCard from './DataSourceCard';
import HotspotCard from './HotspotCard';
import TripPlanner from './TripPlanner';
import FloatPlan from './FloatPlan';
import FishActivity from './FishActivity';

interface Preferences {
  vesselSpeed: string;
  fuelBurnRate: string;
  launchLocation: string;
  preferredSpecies: string[];
  seaSurfaceTemp: { min: string; max: string };
}

interface PredictionsViewProps {
  preferences: Preferences;
}

export default function PredictionsView({ preferences }: PredictionsViewProps) {
  const [analyzing, setAnalyzing] = useState(false);

  const vesselSpeed = parseInt(preferences.vesselSpeed) || 25;
  const maxRange = (vesselSpeed * 3).toFixed(0); // 3 hours one way

  // Mock data from various sources - in production, these would come from API calls
  const dataSourceStatus = [
    { name: 'RipCharts', status: 'active', lastUpdate: '5 min ago', quality: 95 },
    { name: 'Nautide Pro', status: 'active', lastUpdate: '12 min ago', quality: 98 },
    { name: 'Satfish', status: 'active', lastUpdate: '8 min ago', quality: 92 },
    { name: 'ROFFS', status: 'active', lastUpdate: '15 min ago', quality: 88 },
  ];

  // AI-generated hotspots based on data analysis - Ocean City, MD area
  const hotspots = [
    {
      id: 1,
      name: 'Poor Man\'s Canyon - Temperature Break',
      coordinates: '38°31\'N 74°28\'W',
      distance: 30.2,
      travelTime: Math.round((30.2 / vesselSpeed) * 60),
      confidence: 94,
      species: ['Yellowfin Tuna', 'Mahi-Mahi', 'White Marlin'],
      reasons: [
        'SST gradient 3.5°F over canyon edge',
        'Upwelling brings nutrients and baitfish',
        'Historical catch data: 91% success rate this week',
        'Current convergence creates feeding zone',
      ],
      conditions: {
        sst: '72°F',
        current: '1.9 kts SW',
        depth: '600-900 ft',
        chlorophyll: 'High',
      },
    },
    {
      id: 2,
      name: 'Great Gull Bank',
      coordinates: '38°27\'N 74°45\'W',
      distance: 17.5,
      travelTime: Math.round((17.5 / vesselSpeed) * 60),
      confidence: 88,
      species: ['Mahi-Mahi', 'Flounder', 'Sea Bass'],
      reasons: [
        'Reef structure concentrates baitfish',
        'Protected from NE wind - calm conditions',
        'Recent reports of mahi on weed lines',
        'Shallow enough for multiple species',
      ],
      conditions: {
        sst: '71°F',
        current: '1.2 kts E',
        depth: '90-120 ft',
        chlorophyll: 'Medium',
      },
    },
    {
      id: 3,
      name: 'The Jackspot - Offshore Lumps',
      coordinates: '38°35\'N 74°18\'W',
      distance: 35.8,
      travelTime: Math.round((35.8 / vesselSpeed) * 60),
      confidence: 82,
      species: ['Tuna', 'Wahoo', 'Bigeye Tuna'],
      reasons: [
        'Bathymetric features attract pelagics',
        'Deep water access to migrating species',
        'Less fishing pressure than nearby canyons',
        'ROFFS shows favorable edge formation',
      ],
      conditions: {
        sst: '70°F',
        current: '2.1 kts S',
        depth: '800-1200 ft',
        chlorophyll: 'Low',
      },
    },
  ];

  const handleAnalyze = () => {
    setAnalyzing(true);
    setTimeout(() => setAnalyzing(false), 2000);
  };

  return (
    <div className="p-4 space-y-4 pb-24">
      {/* Analysis Header */}
      <div className="bg-gradient-to-br from-blue-600 to-purple-700 rounded-xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <Zap size={32} className="text-yellow-300" />
          <div>
            <h1 className="text-xl font-bold">AI Fishing Predictions</h1>
            <p className="text-sm text-blue-100">
              Analyzing {dataSourceStatus.length} data sources
            </p>
          </div>
        </div>
        <button
          onClick={handleAnalyze}
          disabled={analyzing}
          className="w-full bg-white text-blue-700 font-semibold py-3 rounded-lg hover:bg-blue-50 disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {analyzing ? (
            <>
              <div className="w-5 h-5 border-2 border-blue-700 border-t-transparent rounded-full animate-spin"></div>
              Analyzing...
            </>
          ) : (
            <>
              <TrendingUp size={20} />
              Refresh Predictions
            </>
          )}
        </button>
      </div>

      {/* Vessel Range Info */}
      {preferences.vesselSpeed && (
        <div className="bg-slate-800 rounded-xl p-4 border-2 border-blue-500">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Navigation2 className="text-blue-400" size={24} />
              <div>
                <p className="font-semibold">Vessel Range</p>
                <p className="text-sm text-slate-400">Based on {preferences.vesselSpeed} kts cruising</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-blue-400">{maxRange} mi</p>
              <p className="text-xs text-slate-500">Max recommended</p>
            </div>
          </div>
        </div>
      )}

      {/* Data Source Status */}
      <div>
        <h2 className="font-semibold text-lg mb-3 flex items-center gap-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          Live Data Sources
        </h2>
        <div className="grid grid-cols-2 gap-3">
          {dataSourceStatus.map((source) => (
            <DataSourceCard key={source.name} {...source} />
          ))}
        </div>
      </div>

      {/* Fish Activity Forecast */}
      <FishActivity />

      {/* Species Targeting */}
      {preferences.preferredSpecies.length > 0 && (
        <div className="bg-slate-800 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-3">
            <Fish className="text-blue-400" size={20} />
            <h3 className="font-semibold">Targeting</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {preferences.preferredSpecies.map((species) => (
              <span
                key={species}
                className="px-3 py-1 bg-blue-600 rounded-full text-sm font-medium"
              >
                {species}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Top Recommendations */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-lg">Top Hotspots Today</h2>
          <span className="text-xs text-slate-500">Updated 5 min ago</span>
        </div>
        <div className="space-y-3">
          {hotspots.map((hotspot, index) => (
            <HotspotCard
              key={hotspot.id}
              hotspot={hotspot}
              rank={index + 1}
              vesselSpeed={vesselSpeed}
              preferredSpecies={preferences.preferredSpecies}
            />
          ))}
        </div>
      </div>

      {/* Float Plan */}
      <FloatPlan
        vesselSpeed={vesselSpeed}
        fuelBurnRate={parseFloat(preferences.fuelBurnRate) || 2.5}
        launchLocation={preferences.launchLocation}
      />

      {/* Trip Planner */}
      <TripPlanner
        hotspots={hotspots}
        vesselSpeed={vesselSpeed}
        fuelBurnRate={parseFloat(preferences.fuelBurnRate) || 2.5}
        launchLocation={preferences.launchLocation}
      />

      {/* Disclaimer */}
      <div className="bg-yellow-900/30 border border-yellow-600 rounded-xl p-4">
        <div className="flex items-start gap-3">
          <AlertTriangle size={20} className="text-yellow-400 flex-shrink-0 mt-0.5" />
          <div className="text-sm">
            <p className="font-semibold text-yellow-400 mb-1">Predictions are estimates</p>
            <p className="text-yellow-200/80">
              Always verify conditions before departure. Weather can change rapidly.
              Captain's judgment takes precedence over all predictions.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
