import { useState, useEffect } from 'react';
import { Ship, MapPin, Fish, Thermometer, Save, X, Fuel } from 'lucide-react';
import InstallButton from './InstallButton';
import IconGenerator from './IconGenerator';
import PWADebugger from './PWADebugger';

interface Preferences {
  vesselSpeed: string;
  fuelBurnRate: string;
  launchLocation: string;
  preferredSpecies: string[];
  seaSurfaceTemp: { min: string; max: string };
}

interface SettingsViewProps {
  preferences: Preferences;
  onSave: (preferences: Preferences) => void;
}

export default function SettingsView({ preferences, onSave }: SettingsViewProps) {
  const [formData, setFormData] = useState(preferences);
  const [showSuccess, setShowSuccess] = useState(false);

  // Auto-save changes for real-time fuel estimates
  useEffect(() => {
    onSave(formData);
  }, [formData.vesselSpeed, formData.fuelBurnRate]);

  const popularSpecies = [
    'Mahi-Mahi',
    'Tuna',
    'Wahoo',
    'Sailfish',
    'Marlin',
    'Grouper',
    'Snapper',
    'Kingfish',
    'Swordfish',
    'Amberjack',
  ];

  const handleSave = () => {
    onSave(formData);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 2000);
  };

  const toggleSpecies = (species: string) => {
    setFormData((prev) => ({
      ...prev,
      preferredSpecies: prev.preferredSpecies.includes(species)
        ? prev.preferredSpecies.filter((s) => s !== species)
        : [...prev.preferredSpecies, species],
    }));
  };

  return (
    <div className="p-4 space-y-4 pb-24">
      {/* Success Message */}
      {showSuccess && (
        <div className="bg-green-600 rounded-xl p-4 flex items-center gap-3">
          <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center">
            <span className="text-green-600 font-bold text-lg">✓</span>
          </div>
          <span className="font-semibold">Settings saved successfully!</span>
        </div>
      )}

      {/* PWA Debug Status */}
      <PWADebugger />

      {/* Generate Icons First */}
      <IconGenerator />

      {/* Install PWA */}
      <InstallButton />

      {/* Vessel Speed */}
      <div className="bg-slate-800 rounded-xl p-4">
        <div className="flex items-center gap-3 mb-3">
          <Ship className="text-blue-400" size={24} />
          <h2 className="font-semibold text-lg">Vessel Performance</h2>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm text-slate-400 mb-2">
              Average cruising speed (knots)
            </label>
            <input
              type="number"
              value={formData.vesselSpeed}
              onChange={(e) =>
                setFormData({ ...formData, vesselSpeed: e.target.value })
              }
              className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-3 text-white text-lg"
              placeholder="25"
              step="0.5"
            />
            <p className="text-xs text-slate-500 mt-1">
              Used to calculate travel time to waypoints
            </p>
          </div>

          <div>
            <label className="block text-sm text-slate-400 mb-2 flex items-center gap-2">
              <Fuel size={16} className="text-orange-400" />
              Fuel burn rate (gallons per hour)
            </label>
            <input
              type="number"
              value={formData.fuelBurnRate}
              onChange={(e) =>
                setFormData({ ...formData, fuelBurnRate: e.target.value })
              }
              className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-3 text-white text-lg"
              placeholder="2.5"
              step="0.1"
            />
            <p className="text-xs text-slate-500 mt-1">
              At cruising speed - used for fuel consumption estimates
            </p>
          </div>
        </div>
      </div>

      {/* Launch Location */}
      <div className="bg-slate-800 rounded-xl p-4">
        <div className="flex items-center gap-3 mb-3">
          <MapPin className="text-blue-400" size={24} />
          <h2 className="font-semibold text-lg">Launch Location</h2>
        </div>
        <label className="block text-sm text-slate-400 mb-2">
          Home port or marina
        </label>
        <input
          type="text"
          value={formData.launchLocation}
          onChange={(e) =>
            setFormData({ ...formData, launchLocation: e.target.value })
          }
          className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-3 text-white"
          placeholder="e.g., Fort Lauderdale, FL"
        />
        <p className="text-xs text-slate-500 mt-2">
          Your typical departure point for offshore trips
        </p>
      </div>

      {/* Sea Surface Temperature */}
      <div className="bg-slate-800 rounded-xl p-4">
        <div className="flex items-center gap-3 mb-3">
          <Thermometer className="text-blue-400" size={24} />
          <h2 className="font-semibold text-lg">Preferred Sea Surface Temp</h2>
        </div>
        <label className="block text-sm text-slate-400 mb-2">
          Ideal temperature range (°F)
        </label>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs text-slate-500 mb-1">Minimum</label>
            <input
              type="number"
              value={formData.seaSurfaceTemp.min}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  seaSurfaceTemp: {
                    ...formData.seaSurfaceTemp,
                    min: e.target.value,
                  },
                })
              }
              className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-3 text-white"
              placeholder="68"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">Maximum</label>
            <input
              type="number"
              value={formData.seaSurfaceTemp.max}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  seaSurfaceTemp: {
                    ...formData.seaSurfaceTemp,
                    max: e.target.value,
                  },
                })
              }
              className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-3 text-white"
              placeholder="78"
            />
          </div>
        </div>
        <p className="text-xs text-slate-500 mt-2">
          Alerts will notify you when conditions match your preferences
        </p>
      </div>

      {/* Preferred Species */}
      <div className="bg-slate-800 rounded-xl p-4">
        <div className="flex items-center gap-3 mb-3">
          <Fish className="text-blue-400" size={24} />
          <h2 className="font-semibold text-lg">Preferred Species</h2>
        </div>
        <label className="block text-sm text-slate-400 mb-3">
          Select the species you target most often
        </label>
        <div className="flex flex-wrap gap-2">
          {popularSpecies.map((species) => (
            <button
              key={species}
              onClick={() => toggleSpecies(species)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                formData.preferredSpecies.includes(species)
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
              }`}
            >
              {formData.preferredSpecies.includes(species) && (
                <span className="mr-1">✓</span>
              )}
              {species}
            </button>
          ))}
        </div>
        <p className="text-xs text-slate-500 mt-3">
          {formData.preferredSpecies.length} species selected
        </p>
      </div>

      {/* Save Button */}
      <button
        onClick={handleSave}
        className="w-full bg-blue-600 hover:bg-blue-700 py-4 rounded-xl font-semibold flex items-center justify-center gap-2 text-lg"
      >
        <Save size={24} />
        Save Preferences
      </button>

      {/* Reset to Defaults */}
      <button
        onClick={() =>
          setFormData({
            vesselSpeed: '25',
            fuelBurnRate: '2.5',
            launchLocation: '',
            preferredSpecies: [],
            seaSurfaceTemp: { min: '68', max: '78' },
          })
        }
        className="w-full bg-slate-700 hover:bg-slate-600 py-3 rounded-xl font-medium flex items-center justify-center gap-2"
      >
        <X size={20} />
        Reset to Defaults
      </button>
    </div>
  );
}
