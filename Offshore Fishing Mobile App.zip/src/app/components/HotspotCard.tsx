import { useState } from 'react';
import { MapPin, Fish, Clock, TrendingUp, ChevronDown, ChevronUp, Navigation } from 'lucide-react';

interface Hotspot {
  id: number;
  name: string;
  coordinates: string;
  distance: number;
  travelTime: number;
  confidence: number;
  species: string[];
  reasons: string[];
  conditions: {
    sst: string;
    current: string;
    depth: string;
    chlorophyll: string;
  };
}

interface HotspotCardProps {
  hotspot: Hotspot;
  rank: number;
  vesselSpeed: number;
  preferredSpecies: string[];
}

export default function HotspotCard({ hotspot, rank, vesselSpeed, preferredSpecies }: HotspotCardProps) {
  const [expanded, setExpanded] = useState(false);

  const matchingSpecies = hotspot.species.filter((s) =>
    preferredSpecies.includes(s)
  );

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 90) return 'text-green-400';
    if (confidence >= 75) return 'text-yellow-400';
    return 'text-orange-400';
  };

  const getConfidenceBg = (confidence: number) => {
    if (confidence >= 90) return 'bg-green-400';
    if (confidence >= 75) return 'bg-yellow-400';
    return 'bg-orange-400';
  };

  return (
    <div className={`bg-slate-800 rounded-xl overflow-hidden border-2 ${
      rank === 1 ? 'border-yellow-500' : 'border-transparent'
    }`}>
      {/* Header */}
      <div className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-start gap-3 flex-1">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-lg flex-shrink-0">
              #{rank}
            </div>
            <div className="flex-1">
              <h3 className="font-semibold mb-1">{hotspot.name}</h3>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <MapPin size={12} />
                <span>{hotspot.coordinates}</span>
              </div>
            </div>
          </div>
          <div className={`text-right ${getConfidenceColor(hotspot.confidence)}`}>
            <p className="text-2xl font-bold">{hotspot.confidence}%</p>
            <p className="text-xs">Confidence</p>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-3 mb-3">
          <div className="bg-slate-700 rounded-lg p-2 text-center">
            <p className="text-xs text-slate-400">Distance</p>
            <p className="font-semibold">{hotspot.distance} mi</p>
          </div>
          <div className="bg-slate-700 rounded-lg p-2 text-center">
            <p className="text-xs text-slate-400">Travel</p>
            <p className="font-semibold">{hotspot.travelTime} min</p>
          </div>
          <div className="bg-slate-700 rounded-lg p-2 text-center">
            <p className="text-xs text-slate-400">Depth</p>
            <p className="font-semibold">{hotspot.conditions.depth}</p>
          </div>
        </div>

        {/* Species */}
        <div className="mb-3">
          <div className="flex items-center gap-2 mb-2">
            <Fish size={14} className="text-blue-400" />
            <span className="text-xs text-slate-400">Target Species</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {hotspot.species.map((species) => (
              <span
                key={species}
                className={`px-2 py-1 rounded-full text-xs font-medium ${
                  matchingSpecies.includes(species)
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-700 text-slate-300'
                }`}
              >
                {species}
                {matchingSpecies.includes(species) && ' ✓'}
              </span>
            ))}
          </div>
        </div>

        {/* Expand/Collapse Button */}
        <button
          onClick={() => setExpanded(!expanded)}
          className="w-full bg-slate-700 hover:bg-slate-600 py-2 rounded-lg text-sm font-medium flex items-center justify-center gap-2"
        >
          {expanded ? (
            <>
              Hide Details <ChevronUp size={16} />
            </>
          ) : (
            <>
              View Analysis <ChevronDown size={16} />
            </>
          )}
        </button>
      </div>

      {/* Expanded Details */}
      {expanded && (
        <div className="px-4 pb-4 space-y-3 border-t border-slate-700 pt-3">
          {/* AI Analysis Reasons */}
          <div>
            <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
              <TrendingUp size={14} className="text-green-400" />
              Why This Spot
            </h4>
            <ul className="space-y-1.5">
              {hotspot.reasons.map((reason, idx) => (
                <li key={idx} className="text-sm text-slate-300 flex items-start gap-2">
                  <span className="text-green-400 mt-1">•</span>
                  <span>{reason}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Current Conditions */}
          <div>
            <h4 className="text-sm font-semibold mb-2">Current Conditions</h4>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="bg-slate-700 rounded-lg p-2">
                <p className="text-xs text-slate-400">SST</p>
                <p className="font-semibold">{hotspot.conditions.sst}</p>
              </div>
              <div className="bg-slate-700 rounded-lg p-2">
                <p className="text-xs text-slate-400">Current</p>
                <p className="font-semibold">{hotspot.conditions.current}</p>
              </div>
              <div className="bg-slate-700 rounded-lg p-2">
                <p className="text-xs text-slate-400">Depth</p>
                <p className="font-semibold">{hotspot.conditions.depth}</p>
              </div>
              <div className="bg-slate-700 rounded-lg p-2">
                <p className="text-xs text-slate-400">Chlorophyll</p>
                <p className="font-semibold">{hotspot.conditions.chlorophyll}</p>
              </div>
            </div>
          </div>

          {/* Action Button */}
          <button className="w-full bg-blue-600 hover:bg-blue-700 py-3 rounded-lg font-semibold flex items-center justify-center gap-2">
            <Navigation size={18} />
            Navigate to Hotspot
          </button>
        </div>
      )}
    </div>
  );
}
