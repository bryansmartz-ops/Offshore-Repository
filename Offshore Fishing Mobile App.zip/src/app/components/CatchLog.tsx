import { useState } from 'react';
import { Plus, Fish, MapPin, Clock, Ruler } from 'lucide-react';

export default function CatchLog() {
  const [showForm, setShowForm] = useState(false);

  const catches = [
    {
      species: 'Mahi-Mahi',
      weight: '22 lbs',
      length: '38 in',
      time: '10:30 AM',
      location: '26°24\'N 80°03\'W',
      photo: null,
    },
    {
      species: 'Yellowfin Tuna',
      weight: '45 lbs',
      length: '42 in',
      time: '9:15 AM',
      location: '26°22\'N 80°05\'W',
      photo: null,
    },
    {
      species: 'Mahi-Mahi',
      weight: '18 lbs',
      length: '34 in',
      time: '8:45 AM',
      location: '26°20\'N 80°04\'W',
      photo: null,
    },
  ];

  return (
    <div className="p-4 space-y-4">
      {/* Header Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-slate-800 rounded-xl p-3 text-center">
          <p className="text-3xl font-bold text-blue-400">3</p>
          <p className="text-sm text-slate-400">Today</p>
        </div>
        <div className="bg-slate-800 rounded-xl p-3 text-center">
          <p className="text-3xl font-bold text-green-400">85</p>
          <p className="text-sm text-slate-400">lbs Total</p>
        </div>
        <div className="bg-slate-800 rounded-xl p-3 text-center">
          <p className="text-3xl font-bold text-purple-400">12</p>
          <p className="text-sm text-slate-400">This Week</p>
        </div>
      </div>

      {/* Add Catch Button */}
      <button
        onClick={() => setShowForm(!showForm)}
        className="w-full bg-blue-600 hover:bg-blue-700 py-3 rounded-xl font-semibold flex items-center justify-center gap-2"
      >
        <Plus size={20} />
        Log New Catch
      </button>

      {/* Quick Log Form */}
      {showForm && (
        <div className="bg-slate-800 rounded-xl p-4 space-y-3">
          <input
            type="text"
            placeholder="Species"
            className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white placeholder-slate-400"
          />
          <div className="grid grid-cols-2 gap-3">
            <input
              type="text"
              placeholder="Weight (lbs)"
              className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white placeholder-slate-400"
            />
            <input
              type="text"
              placeholder="Length (in)"
              className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white placeholder-slate-400"
            />
          </div>
          <div className="flex gap-2">
            <button className="flex-1 bg-slate-700 hover:bg-slate-600 py-2 rounded-lg text-sm">
              Add Photo
            </button>
            <button className="flex-1 bg-blue-600 hover:bg-blue-700 py-2 rounded-lg text-sm font-semibold">
              Save Catch
            </button>
          </div>
        </div>
      )}

      {/* Catch List */}
      <div className="space-y-3">
        <h2 className="font-semibold text-lg">Recent Catches</h2>
        {catches.map((catchItem, index) => (
          <div key={index} className="bg-slate-800 rounded-xl p-4">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Fish size={24} />
                </div>
                <div>
                  <p className="font-semibold text-lg">{catchItem.species}</p>
                  <div className="flex items-center gap-2 text-sm text-slate-400">
                    <Clock size={14} />
                    <span>{catchItem.time}</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex items-center gap-2">
                <Ruler size={16} className="text-slate-400" />
                <span className="text-slate-400">Weight:</span>
                <span className="font-semibold">{catchItem.weight}</span>
              </div>
              <div className="flex items-center gap-2">
                <Ruler size={16} className="text-slate-400" />
                <span className="text-slate-400">Length:</span>
                <span className="font-semibold">{catchItem.length}</span>
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-700">
              <div className="flex items-center gap-2 text-sm text-slate-400">
                <MapPin size={14} />
                <span>{catchItem.location}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
